import AppRouter from "./ui/AppRouter";

export {
    AppRouter
}

import React from 'react';

const MainPage = () => {
    return (
        <div>
            MainPage
        </div>
    );
};

export default MainPage;
